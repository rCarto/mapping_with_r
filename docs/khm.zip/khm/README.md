# Toy dataset on Cambodia

Source for the lake:  
https://data.humdata.org/dataset/wfp-geonode-cambodia-admin-boundaries-level-2-districts
Department of Geography of the Ministry of Land Management, Urban Planning and Construction and WFP GeoEnabler Project.

Source for municipalities & districts (ADM2 level):  
https://data.humdata.org/dataset/cod-ab-khm
Department of Geography of the Ministry of Land Management, Urbanization and Construction in 2008 and unofficially updated in 2014 according to sub-decrees on administrative modifications. Data provided by WFP - VAM unit Cambodia.

Source for landmass:   
https://www.naturalearthdata.com/about/terms-of-use/
Made with Natural Earth.

Source for population data:  
https://data.humdata.org/dataset/cod-ps-khm
Year of reference: 2016
